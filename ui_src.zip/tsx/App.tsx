import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Home          from './screens/Home';
import Workspace     from './screens/Workspace';
import AgentEditor   from './screens/AgentEditor';
import SkillLibrary  from './screens/SkillLibrary';
import UploadLetters from './screens/UploadLetters';

export default function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path='/'                   element={<Home />} />
                <Route path='/workspace/:agentId' element={<Workspace />} />
                <Route path='/agent/new'          element={<AgentEditor />} />
                <Route path='/agent/:agentId'     element={<AgentEditor />} />
                <Route path='/skills'             element={<SkillLibrary />} />
                <Route path='/upload'             element={<UploadLetters />} />
                <Route path='*'                   element={<Navigate to='/' />} />
            </Routes>
        </BrowserRouter>
    );
}
