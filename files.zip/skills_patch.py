"""
Add to backend/routes/skills.py
PATCH /api/skills/workflow/{workflow_skill_id} — toggle enabled on workflow_skill
"""
from fastapi import APIRouter, Depends, HTTPException, Request
from aws_secrets import get_pool

# Add this endpoint to existing skills router in skills.py

'''
@router.patch("/skills/workflow/{workflow_skill_id}")
async def toggle_workflow_skill(
    workflow_skill_id: str,
    request: Request,
    body: dict,
    pool=Depends(get_pool)
):
    enabled = body.get("enabled", True)
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT id FROM workflow_skill WHERE id = $1",
            workflow_skill_id
        )
        if not row:
            raise HTTPException(status_code=404, detail="Workflow skill not found")

        await conn.execute("""
            UPDATE workflow_skill
            SET enabled = $1
            WHERE id = $2
        """, enabled, workflow_skill_id)

    return {"id": workflow_skill_id, "enabled": enabled}
'''
