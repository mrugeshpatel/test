import { useState } from 'react';
import { LogEntry } from '../hooks/useWebSocket';

interface Props {
    logs:      LogEntry[];
    connected: boolean;
}

export default function ExecutionLog({ logs, connected }: Props) {
    const [open,         setOpen]         = useState(false);
    const [expandedStep, setExpandedStep] = useState<number | null>(null);

    const toggleExpand = (i: number) => {
        setExpandedStep(prev => prev === i ? null : i);
    };

    return (
        <div className='collapse-card'>
            <div className='collapse-header' onClick={() => setOpen(o => !o)}>
                <span className='ch-title'>Execution log</span>
                <span className='ch-meta'>
                    {logs.filter(l => l.type === 'node_end').length} steps completed
                    {connected ? ' · live' : ''}
                </span>
                <span className={`chevron ${open ? 'open' : ''}`}>▼</span>
            </div>
            {open && (
                <div className='collapse-body open'>
                    <div className='exec-log'>
                        {logs.length === 0 && (
                            <div className='exec-empty'>
                                No log entries yet · send a message to start
                            </div>
                        )}
                        {logs.map((log, i) => (
                            <div key={i}>

                                {/* Node running */}
                                {log.type === 'node_start' && (
                                    <div className='exec-row'>
                                        <span className='exec-ic running'>●</span>
                                        <span className='exec-label'>{log.message}</span>
                                        <span className='exec-status running'>running</span>
                                    </div>
                                )}

                                {/* Node done */}
                                {log.type === 'node_end' && (
                                    <div className='exec-row'>
                                        <span className='exec-ic done'>✓</span>
                                        <span className='exec-label'>{log.message}</span>
                                        <span className='exec-status done'>done</span>
                                    </div>
                                )}

                                {/* Prompt sent to Bedrock — expandable */}
                                {log.type === 'prompt' && (
                                    <div className='exec-prompt-wrap'>
                                        <div
                                            className='exec-prompt-toggle'
                                            onClick={() => toggleExpand(i)}>
                                            <span className='exec-prompt-icon'>
                                                {expandedStep === i ? '▼' : '▶'}
                                            </span>
                                            <span className='exec-prompt-label'>
                                                Prompt sent to Bedrock
                                                {log.step ? ` — ${log.step}` : ''}
                                            </span>
                                        </div>
                                        {expandedStep === i && (
                                            <pre className='exec-prompt-body'>
                                                {log.message}
                                            </pre>
                                        )}
                                    </div>
                                )}

                                {/* Bedrock response — expandable */}
                                {log.type === 'response' && (
                                    <div className='exec-prompt-wrap'>
                                        <div
                                            className='exec-prompt-toggle'
                                            onClick={() => toggleExpand(i)}>
                                            <span className='exec-prompt-icon'>
                                                {expandedStep === i ? '▼' : '▶'}
                                            </span>
                                            <span className='exec-prompt-label'
                                                style={{ color: '#065F46' }}>
                                                Bedrock response
                                                {log.step ? ` — ${log.step}` : ''}
                                            </span>
                                        </div>
                                        {expandedStep === i && (
                                            <pre className='exec-prompt-body'
                                                style={{ borderColor: '#D1FAE5' }}>
                                                {log.message}
                                            </pre>
                                        )}
                                    </div>
                                )}

                                {/* Error */}
                                {log.type === 'error' && (
                                    <div className='exec-row'>
                                        <span className='exec-ic'
                                            style={{ background: '#FEE2E2', color: '#991B1B' }}>
                                            !
                                        </span>
                                        <span className='exec-label'
                                            style={{ color: '#991B1B' }}>
                                            {log.message}
                                        </span>
                                    </div>
                                )}

                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}
