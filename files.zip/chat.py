"""
backend/routes/chat.py
POST /api/chat            — send message, run LangGraph graph, return reply
GET  /api/chat/history/id — get chat history for session
WS   /ws/chat/{id}        — live execution log stream via asyncio Queue + Event
"""

import asyncio
import json
import logging

from fastapi import APIRouter, Depends, HTTPException, Request, WebSocket, WebSocketDisconnect
from pydantic import BaseModel

from aws_secrets import get_pool
from graph.builder      import build_graph_from_agent
from graph.checkpointer import init_langgraph

logger = logging.getLogger(__name__)
router = APIRouter()

# ── Session queues + events ───────────────────────────────────
_session_queues: dict[str, asyncio.Queue] = {}
_session_events: dict[str, asyncio.Event] = {}


class ChatRequest(BaseModel):
    session_id: str
    content:    str


# ── POST /api/chat ───────────────────────────────────────────
@router.post("/chat")
async def chat(request: Request, body: ChatRequest, pool=Depends(get_pool)):
    user_id = request.state.user_id

    async with pool.acquire() as conn:
        session = await conn.fetchrow(
            "SELECT * FROM chat_session WHERE id=$1 AND user_id=$2",
            body.session_id, user_id
        )
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        agent = await conn.fetchrow(
            "SELECT * FROM agent WHERE id=$1", session["agent_id"]
        )
        if not agent:
            raise HTTPException(status_code=404, detail="Agent not found")

        agent_dict = dict(agent)

        skills = await conn.fetch("""
            SELECT ws.*, s.name as skill_name, s.content, ds.name as ds_name
            FROM workflow_skill ws
            JOIN skill s ON s.id = ws.skill_id
            LEFT JOIN data_source ds ON ds.id = s.data_source_id
            WHERE ws.workflow_id = $1 AND ws.enabled = true
            ORDER BY ws.step_order
        """, agent_dict.get("workflow_id"))

        agent_dict["workflow_skills"] = [dict(s) for s in skills]

        await conn.execute("""
            INSERT INTO chat_message (session_id, role, content)
            VALUES ($1, 'user', $2)
        """, body.session_id, body.content)

    try:
        checkpointer, store = await init_langgraph(pool)
        graph = build_graph_from_agent(agent_dict, checkpointer, store)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Graph build failed: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to build agent graph: {str(e)}")

    thread_id = session["thread_id"] or str(session["id"])
    config = {
        "configurable": {
            "thread_id":     thread_id,
            "pool":          pool,
            "store":         store,
            "user_id":       user_id,
            "agent_id":      str(session["agent_id"]),
            "system_prompt": agent_dict.get("system_prompt") or "",
            "guardrails":    agent_dict.get("guardrails")    or "",
        }
    }

    # Create queue and signal WS
    queue = asyncio.Queue()
    _session_queues[body.session_id] = queue
    event = _session_events.setdefault(body.session_id, asyncio.Event())
    event.set()

    reply = ""
    try:
        async for ev in graph.astream_events(
            {"messages": [{"role": "user", "content": body.content}]},
            config=config,
            version="v2"
        ):
            kind = ev.get("event", "")
            name = ev.get("name",  "")
            data = ev.get("data",  {})

            # Node started
            if kind == "on_chain_start" and name:
                await queue.put({
                    "type":    "node_start",
                    "step":    name,
                    "status":  "running",
                    "message": f"Running {name}...",
                })

            # Full prompt sent to Bedrock
            elif kind == "on_chat_model_start":
                try:
                    inputs      = data.get("input", {})
                    logger.info(f"on_chat_model_start keys: {list(inputs.keys())}")
                    messages    = inputs.get("messages", [])
                    prompt_text = ""
                    for msg_list in messages:
                        items = msg_list if isinstance(msg_list, list) else [msg_list]
                        for msg in items:
                            role    = getattr(msg, "type", None) or \
                                      (msg.get("role") if isinstance(msg, dict) else "unknown")
                            content = getattr(msg, "content", None) or \
                                      (msg.get("content") if isinstance(msg, dict) else "")
                            if content:
                                prompt_text += f"[{str(role).upper()}]\n{content}\n\n"

                    if prompt_text:
                        await queue.put({
                            "type":    "prompt",
                            "step":    name or "bedrock",
                            "status":  "info",
                            "message": prompt_text.strip(),
                        })
                    else:
                        logger.warning(f"on_chat_model_start: no prompt text captured. data={data}")
                except Exception as e:
                    logger.warning(f"Could not capture prompt: {e}")

            # Bedrock response per node
            elif kind == "on_chat_model_end":
                try:
                    output  = data.get("output", {})
                    content = ""
                    if hasattr(output, "content"):
                        content = output.content
                    elif isinstance(output, dict):
                        content = output.get("content", "")
                    if content:
                        await queue.put({
                            "type":    "response",
                            "step":    name or "bedrock",
                            "status":  "info",
                            "message": content,
                        })
                except Exception as e:
                    logger.warning(f"Could not capture response: {e}")

            # Node completed
            elif kind == "on_chain_end" and name:
                output = data.get("output", {})
                msgs   = output.get("messages", []) if isinstance(output, dict) else []
                if msgs:
                    last  = msgs[-1]
                    reply = last.content if hasattr(last, "content") else str(last)
                    await queue.put({
                        "type":    "node_end",
                        "step":    name,
                        "status":  "done",
                        "message": f"{name} complete",
                        "reply":   reply,
                    })

    except Exception as e:
        logger.error(f"Graph invocation failed: {e}")
        await queue.put({"type": "error", "message": str(e), "status": "error"})
        raise HTTPException(status_code=500, detail=f"Agent execution failed: {str(e)}")

    finally:
        await queue.put(None)
        async def cleanup():
            await asyncio.sleep(10)
            _session_queues.pop(body.session_id, None)
        asyncio.create_task(cleanup())

    if not reply:
        raise HTTPException(status_code=500, detail="Agent returned no reply")

    async with pool.acquire() as conn:
        await conn.execute("""
            INSERT INTO chat_message (session_id, role, content)
            VALUES ($1, 'assistant', $2)
        """, body.session_id, reply)
        await conn.execute(
            "UPDATE chat_session SET updated_on = NOW() WHERE id = $1",
            body.session_id
        )

    return {"reply": reply, "session_id": body.session_id}


# ── GET /api/chat/history ────────────────────────────────────
@router.get("/chat/history/{session_id}")
async def chat_history(session_id: str, request: Request, pool=Depends(get_pool)):
    user_id = request.state.user_id

    async with pool.acquire() as conn:
        session = await conn.fetchrow(
            "SELECT * FROM chat_session WHERE id=$1 AND user_id=$2",
            session_id, user_id
        )
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        messages = await conn.fetch("""
            SELECT id, session_id, role, content, created_on
            FROM chat_message
            WHERE session_id = $1
            ORDER BY created_on ASC
        """, session_id)

    return [dict(m) for m in messages]


# ── WebSocket /ws/chat/{session_id} ─────────────────────────
async def chat_ws(websocket: WebSocket, session_id: str):
    await websocket.accept()
    logger.info(f"WebSocket connected: session={session_id}")

    # Ensure event exists for this session
    event = _session_events.setdefault(session_id, asyncio.Event())

    try:
        while True:
            # Wait for POST to signal queue is ready
            try:
                await asyncio.wait_for(event.wait(), timeout=300)
            except asyncio.TimeoutError:
                # Send ping to keep WS alive then loop
                try:
                    await websocket.send_json({"type": "ping"})
                    continue
                except Exception:
                    break

            # Reset event for next message
            event.clear()

            # Get queue
            queue = _session_queues.get(session_id)
            if not queue:
                continue

            # Drain queue — stream events to frontend
            while True:
                try:
                    msg = await asyncio.wait_for(queue.get(), timeout=120)
                except asyncio.TimeoutError:
                    break

                if msg is None:
                    break

                try:
                    await websocket.send_json(msg)
                except Exception as e:
                    logger.warning(f"WS send failed: {e}")
                    break

    except WebSocketDisconnect:
        logger.info(f"WebSocket disconnected: session={session_id}")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    finally:
        _session_events.pop(session_id, None)
        try:
            await websocket.close()
        except Exception:
            pass  # already closed
