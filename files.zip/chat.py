"""
backend/routes/chat.py
POST /api/chat       — send message, run LangGraph graph, return reply
WS   /ws/chat/{id}  — live execution log stream
"""

import json
import logging

from fastapi import APIRouter, Depends, HTTPException, Request, WebSocket, WebSocketDisconnect
from pydantic import BaseModel

from aws_secrets import get_pool
from graph.builder      import build_graph_from_agent
from graph.checkpointer import init_langgraph

logger = logging.getLogger(__name__)
router = APIRouter()


class ChatRequest(BaseModel):
    session_id: str
    content:    str


# ── POST /api/chat ───────────────────────────────────────────
@router.post("/chat")
async def chat(request: Request, body: ChatRequest, pool=Depends(get_pool)):
    user_id = request.state.user_id

    async with pool.acquire() as conn:
        # Get session
        session = await conn.fetchrow(
            "SELECT * FROM chat_session WHERE id=$1 AND user_id=$2",
            body.session_id, user_id
        )
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        # Get agent — including system_prompt and guardrails
        agent = await conn.fetchrow(
            "SELECT * FROM agent WHERE id=$1", session["agent_id"]
        )
        if not agent:
            raise HTTPException(status_code=404, detail="Agent not found")

        agent_dict = dict(agent)

        # Get workflow skills
        skills = await conn.fetch("""
            SELECT ws.*, s.name as skill_name, s.content, ds.name as ds_name
            FROM workflow_skill ws
            JOIN skill s ON s.id = ws.skill_id
            LEFT JOIN data_source ds ON ds.id = s.data_source_id
            WHERE ws.workflow_id = $1 AND ws.enabled = true
            ORDER BY ws.step_order
        """, agent_dict.get("workflow_id"))

        agent_dict["workflow_skills"] = [dict(s) for s in skills]

        # Save user message
        await conn.execute("""
            INSERT INTO chat_message (session_id, role, content)
            VALUES ($1, 'user', $2)
        """, body.session_id, body.content)

    # Build LangGraph graph
    try:
        checkpointer, store = await init_langgraph(pool)
        graph = build_graph_from_agent(agent_dict, checkpointer, store)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Graph build failed: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to build agent graph: {str(e)}")

    # Run graph — pass system_prompt and guardrails via configurable
    # so nodes can use them as the cached system block in Bedrock calls
    thread_id = session["thread_id"] or str(session["id"])
    config = {
        "configurable": {
            "thread_id":     thread_id,
            "pool":          pool,
            "store":         store,
            "user_id":       user_id,
            "agent_id":      str(session["agent_id"]),
            "system_prompt": agent_dict.get("system_prompt") or "",
            "guardrails":    agent_dict.get("guardrails")    or "",
        }
    }

    try:
        result = await graph.ainvoke(
            {"messages": [{"role": "user", "content": body.content}]},
            config=config
        )
    except Exception as e:
        logger.error(f"Graph invocation failed: {e}")
        raise HTTPException(status_code=500, detail=f"Agent execution failed: {str(e)}")

    # Extract reply
    messages = result.get("messages", [])
    if not messages:
        raise HTTPException(status_code=500, detail="Agent returned no messages")

    last  = messages[-1]
    reply = last.content if hasattr(last, "content") else (
        last.get("content", "") if isinstance(last, dict) else str(last)
    )

    # Save assistant message + update session activity
    async with pool.acquire() as conn:
        await conn.execute("""
            INSERT INTO chat_message (session_id, role, content)
            VALUES ($1, 'assistant', $2)
        """, body.session_id, reply)

        await conn.execute(
            "UPDATE chat_session SET updated_on = NOW() WHERE id = $1",
            body.session_id
        )

    return {"reply": reply, "session_id": body.session_id}


# ── GET /api/chat/history ────────────────────────────────────
@router.get("/chat/history/{session_id}")
async def chat_history(session_id: str, request: Request, pool=Depends(get_pool)):
    user_id = request.state.user_id

    async with pool.acquire() as conn:
        session = await conn.fetchrow(
            "SELECT * FROM chat_session WHERE id=$1 AND user_id=$2",
            session_id, user_id
        )
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        messages = await conn.fetch("""
            SELECT id, session_id, role, content, created_on
            FROM chat_message
            WHERE session_id = $1
            ORDER BY created_on ASC
        """, session_id)

    return [dict(m) for m in messages]


# ── WebSocket /ws/chat/{session_id} ─────────────────────────
@router.websocket("/ws/chat/{session_id}")
async def chat_ws(websocket: WebSocket, session_id: str):
    pool = websocket.app.state.pool
    await websocket.accept()
    logger.info(f"WebSocket connected: session={session_id}")

    try:
        while True:
            data    = await websocket.receive_text()
            payload = json.loads(data)
            content = payload.get("content", "")
            if not content:
                continue

            user_id = payload.get("user_id", "")

            async with pool.acquire() as conn:
                session = await conn.fetchrow(
                    "SELECT * FROM chat_session WHERE id=$1", session_id
                )
                if not session:
                    await websocket.send_json({"type": "error", "message": "Session not found"})
                    continue

                agent = await conn.fetchrow(
                    "SELECT * FROM agent WHERE id=$1", session["agent_id"]
                )
                agent_dict = dict(agent)

                skills = await conn.fetch("""
                    SELECT ws.*, s.name as skill_name, s.content, ds.name as ds_name
                    FROM workflow_skill ws
                    JOIN skill s ON s.id = ws.skill_id
                    LEFT JOIN data_source ds ON ds.id = s.data_source_id
                    WHERE ws.workflow_id = $1 AND ws.enabled = true
                    ORDER BY ws.step_order
                """, agent_dict.get("workflow_id"))
                agent_dict["workflow_skills"] = [dict(s) for s in skills]

            try:
                checkpointer, store = await init_langgraph(pool)
                graph = build_graph_from_agent(agent_dict, checkpointer, store)

                thread_id = session["thread_id"] or str(session["id"])
                config = {
                    "configurable": {
                        "thread_id":     thread_id,
                        "pool":          pool,
                        "store":         store,
                        "user_id":       user_id,
                        "agent_id":      str(session["agent_id"]),
                        "system_prompt": agent_dict.get("system_prompt") or "",
                        "guardrails":    agent_dict.get("guardrails")    or "",
                    }
                }

                async for event in graph.astream_events(
                    {"messages": [{"role": "user", "content": content}]},
                    config=config,
                    version="v2"
                ):
                    kind = event.get("event", "")
                    name = event.get("name",  "")

                    if kind == "on_chain_start" and name:
                        await websocket.send_json({
                            "type":    "node_start",
                            "step":    name,
                            "status":  "running",
                            "message": f"Running {name}...",
                        })

                    elif kind == "on_chain_end" and name:
                        output = event.get("data", {}).get("output", {})
                        reply  = ""
                        if isinstance(output, dict):
                            msgs = output.get("messages", [])
                            if msgs:
                                last  = msgs[-1]
                                reply = last.content if hasattr(last, "content") else str(last)

                        await websocket.send_json({
                            "type":    "node_end",
                            "step":    name,
                            "status":  "done",
                            "message": reply or f"{name} complete",
                            "reply":   reply,
                        })

            except Exception as e:
                logger.error(f"WS graph error: {e}")
                await websocket.send_json({
                    "type":    "error",
                    "message": str(e),
                    "status":  "error",
                })

    except WebSocketDisconnect:
        logger.info(f"WebSocket disconnected: session={session_id}")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        await websocket.close()
