import { useEffect, useRef, useState, useCallback } from 'react';

export interface LogEntry {
    type:     string;   // node_start | node_end | prompt | response | error | done | ping | timeout
    step:     string;
    status:   string;
    message:  string;
    reply?:   string;
}

export function useWebSocket(sessionId: string | null) {
    const [logs,      setLogs]      = useState<LogEntry[]>([]);
    const [connected, setConnected] = useState(false);
    const wsRef = useRef<WebSocket | null>(null);

    useEffect(() => {
        if (!sessionId) return;

        const ws = new WebSocket(
            `ws://${window.location.host}/backend/ws/chat/${sessionId}`
        );
        wsRef.current = ws;

        ws.onopen = () => {
            setConnected(true);
        };

        ws.onclose = () => {
            setConnected(false);
        };

        ws.onerror = (e) => {
            console.error('WebSocket error:', e);
            setConnected(false);
        };

        ws.onmessage = (e) => {
            try {
                const entry: LogEntry = JSON.parse(e.data);

                // Ignore control/keep-alive messages
                if (
                    entry.type === 'ping'    ||
                    entry.type === 'done'    ||
                    entry.type === 'timeout'
                ) {
                    return;
                }

                // Add all real events to log
                setLogs(prev => [...prev, entry]);

            } catch (err) {
                console.error('WS parse error:', err);
            }
        };

        return () => {
            ws.close();
            setLogs([]);
        };
    }, [sessionId]);

    const clearLogs = useCallback(() => setLogs([]), []);

    return { logs, connected, clearLogs };
}
