import { useEffect, useRef, useState, useCallback } from 'react';

export interface LogEntry {
    type:     string;   // node_start | node_end | prompt | error | done | timeout
    step:     string;
    status:   string;
    message:  string;
    reply?:   string;
}

export function useWebSocket(sessionId: string | null) {
    const [logs,      setLogs]      = useState<LogEntry[]>([]);
    const [connected, setConnected] = useState(false);
    const wsRef = useRef<WebSocket | null>(null);

    useEffect(() => {
        if (!sessionId) return;

        const ws = new WebSocket(
            `ws://${window.location.host}/backend/ws/chat/${sessionId}`
        );
        wsRef.current = ws;

        ws.onopen = () => {
            setConnected(true);
        };

        ws.onclose = () => {
            setConnected(false);
        };

        ws.onmessage = (e) => {
            try {
                const entry: LogEntry = JSON.parse(e.data);

                // Skip done/timeout — just update connected state
                if (entry.type === 'done' || entry.type === 'timeout') {
                    setConnected(false);
                    return;
                }

                // Add all other events to log
                setLogs(prev => [...prev, entry]);

            } catch (err) {
                console.error('WS parse error:', err);
            }
        };

        ws.onerror = (e) => {
            console.error('WebSocket error:', e);
            setConnected(false);
        };

        return () => {
            ws.close();
            setLogs([]);
        };
    }, [sessionId]);

    const clearLogs = useCallback(() => setLogs([]), []);

    return { logs, connected, clearLogs };
}
