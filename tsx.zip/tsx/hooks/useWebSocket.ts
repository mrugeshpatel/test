import { useEffect, useRef, useState, useCallback } from 'react';

export interface LogEntry {
    type:    string;
    step:    string;
    status:  string;
    message: string;
}

export function useWebSocket(sessionId: string | null) {
    const [logs, setLogs]           = useState<LogEntry[]>([]);
    const [connected, setConnected] = useState(false);
    const wsRef = useRef<WebSocket | null>(null);

    useEffect(() => {
        if (!sessionId) return;
        const ws = new WebSocket(`ws://${window.location.host}/ws/chat/${sessionId}`);
        wsRef.current = ws;
        ws.onopen    = () => setConnected(true);
        ws.onclose   = () => setConnected(false);
        ws.onmessage = (e) => {
            try {
                const entry: LogEntry = JSON.parse(e.data);
                setLogs(prev => [...prev, entry]);
            } catch {}
        };
        return () => { ws.close(); setLogs([]); };
    }, [sessionId]);

    const clearLogs = useCallback(() => setLogs([]), []);
    return { logs, connected, clearLogs };
}
