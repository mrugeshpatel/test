import { useState, useCallback } from 'react';
import { ChatMessage } from '../types';
import { sendMessage } from '../api/sessions';

export function useChat(sessionId: string | null) {
    const [messages,    setMessages]    = useState<ChatMessage[]>([]);
    const [sending,     setSending]     = useState(false);
    const [letterDraft, setLetterDraft] = useState<string | null>(null);

    const send = useCallback(async (content: string) => {
        if (!sessionId || !content.trim()) return;
        setSending(true);
        const userMsg: ChatMessage = {
            id: Date.now().toString(), session_id: sessionId,
            role: 'user', content, created_on: new Date().toISOString(),
        };
        setMessages(prev => [...prev, userMsg]);
        try {
            const result = await sendMessage(sessionId, content);
            const assistantMsg: ChatMessage = {
                id: Date.now().toString() + '_a', session_id: sessionId,
                role: 'assistant', content: result.reply,
                created_on: new Date().toISOString(),
            };
            setMessages(prev => [...prev, assistantMsg]);
            if (result.letter_draft) setLetterDraft(result.letter_draft);
        } finally {
            setSending(false);
        }
    }, [sessionId]);

    return { messages, setMessages, sending, send, letterDraft };
}
