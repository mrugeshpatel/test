import { BrowserRouter, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import Home          from './screens/Home';
import Workspace     from './screens/Workspace';
import AgentEditor   from './screens/AgentEditor';
import SkillLibrary  from './screens/SkillLibrary';
import UploadLetters from './screens/UploadLetters';

function Layout() {
    const navigate = useNavigate();
    const location = useLocation();

    const navItems = [
        { label: 'Home',           path: '/' },
        { label: 'Chat',           path: '/workspace' },
        { label: 'Create agent',   path: '/agent/new' },
        { label: 'Skill library',  path: '/skills' },
        { label: 'Upload letters', path: '/upload' },
    ];

    const isActive = (path: string) => {
        if (path === '/') return location.pathname === '/';
        return location.pathname.startsWith(path);
    };

    return (
        <div className='page-wrapper'>
            {/* Barclays Header */}
            <div className='barcl-header'>
                <div className='barcl-header-top'>
                    <div className='barcl-logo'>
                        <div className='barcl-eagle'>
                            <svg viewBox='0 0 24 24' width='13' height='13' fill='white'>
                                <path d='M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z'/>
                            </svg>
                        </div>
                        <span className='barcl-wordmark'>Barclays</span>
                        <div className='barcl-divider-v'></div>
                        <span className='barcl-app-name'>Banker's One Platform</span>
                    </div>
                    <div className='barcl-nav-right'>
                        <span className='barcl-help'>Help</span>
                        <div className='barcl-user'>
                            <div className='barcl-avatar'>DU</div>
                            <span className='barcl-username'>DU00001</span>
                        </div>
                    </div>
                </div>
                <div className='barcl-subnav'>
                    {navItems.map(item => (
                        <button
                            key={item.path}
                            className={`barcl-nav-tab ${isActive(item.path) ? 'active' : ''}`}
                            onClick={() => navigate(item.path)}>
                            {item.label}
                        </button>
                    ))}
                </div>
            </div>

            {/* Screen content */}
            <div className='page-content'>
                <Routes>
                    <Route path='/'                   element={<Home />} />
                    <Route path='/workspace/:agentId' element={<Workspace />} />
                    <Route path='/workspace'          element={<Home />} />
                    <Route path='/agent/new'          element={<AgentEditor />} />
                    <Route path='/agent/:agentId'     element={<AgentEditor />} />
                    <Route path='/skills'             element={<SkillLibrary />} />
                    <Route path='/upload'             element={<UploadLetters />} />
                    <Route path='*'                   element={<Navigate to='/' />} />
                </Routes>
            </div>

            {/* Barclays Footer */}
            <div className='barcl-footer'>
                <div className='barcl-footer-left'>
                    <span className='barcl-footer-copy'>© 2026 Barclays Bank PLC. All rights reserved.</span>
                    <div className='barcl-footer-links'>
                        <span className='barcl-footer-link'>Privacy policy</span>
                        <span className='barcl-footer-link'>Terms of use</span>
                        <span className='barcl-footer-link'>Accessibility</span>
                        <span className='barcl-footer-link'>Contact support</span>
                    </div>
                </div>
                <span className='barcl-footer-ver'>v1.0.0</span>
            </div>
        </div>
    );
}

export default function App() {
    return (
        <BrowserRouter>
            <Layout />
        </BrowserRouter>
    );
}
