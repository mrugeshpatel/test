import { ActivismLetter, StyleVector } from '../types';

const BASE = '/backend/api';

export const fetchLetters = (): Promise<ActivismLetter[]> =>
    fetch(`${BASE}/letters`).then(r => r.json());

export const fetchVectors = (): Promise<StyleVector[]> =>
    fetch(`${BASE}/letters/vectors`).then(r => r.json());

export const uploadLetters = (files: File[]): Promise<ActivismLetter[]> => {
    const form = new FormData();
    files.forEach(f => form.append('files', f));
    return fetch(`${BASE}/letters/upload`, {
        method: 'POST', body: form,
    }).then(r => r.json());
};

export const updateActivist = (id: string, activist: string): Promise<ActivismLetter> =>
    fetch(`${BASE}/letters/${id}/activist`, {
        method:  'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ activist }),
    }).then(r => r.json());

export const embedLetter = (id: string) =>
    fetch(`${BASE}/letters/${id}/embed`, { method: 'POST' }).then(r => r.json());

export const deleteLetter = (id: string): Promise<void> =>
    fetch(`${BASE}/letters/${id}`, { method: 'DELETE' }).then(() => undefined);

export const deleteVector = (activist: string): Promise<void> =>
    fetch(`${BASE}/letters/vectors/${activist}`, { method: 'DELETE' }).then(() => undefined);
