import { Agent, AgentStatus } from '../types';

const BASE = '/backend/api';

export const fetchAgents = (): Promise<Agent[]> =>
    fetch(`${BASE}/agents`).then(r => r.json());

export const fetchAgent = (id: string): Promise<Agent> =>
    fetch(`${BASE}/agents/${id}`).then(r => r.json());

export const fetchAgentStatus = (id: string): Promise<AgentStatus> =>
    fetch(`${BASE}/agents/${id}/status`).then(r => r.json());

export const createAgent = (body: Partial<Agent>): Promise<Agent> =>
    fetch(`${BASE}/agents`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(body),
    }).then(r => r.json());

export const updateAgent = (id: string, body: Partial<Agent>): Promise<Agent> =>
    fetch(`${BASE}/agents/${id}`, {
        method:  'PUT',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(body),
    }).then(r => r.json());
