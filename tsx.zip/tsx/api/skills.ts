import { Skill } from '../types';

const BASE = '/backend/api';

export const fetchSkills = (): Promise<Skill[]> =>
    fetch(`${BASE}/skills`).then(r => r.json());

export const fetchSkill = (id: string): Promise<Skill> =>
    fetch(`${BASE}/skills/${id}`).then(r => r.json());

export const createSkill = (body: Partial<Skill>): Promise<Skill> =>
    fetch(`${BASE}/skills`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(body),
    }).then(r => r.json());

export const updateSkill = (id: string, body: Partial<Skill>): Promise<Skill> =>
    fetch(`${BASE}/skills/${id}`, {
        method:  'PUT',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(body),
    }).then(r => r.json());

export const deleteSkill = (id: string): Promise<void> =>
    fetch(`${BASE}/skills/${id}`, { method: 'DELETE' }).then(() => undefined);
