import { ChatSession, ChatMessage } from '../types';

const BASE = '/backend/api';

export const fetchSessions = (agentId: string): Promise<ChatSession[]> =>
    fetch(`${BASE}/sessions?agent_id=${agentId}`).then(r => r.json());

export const fetchMessages = (sessionId: string): Promise<ChatMessage[]> =>
    fetch(`${BASE}/sessions/${sessionId}/messages`).then(r => r.json());

export const createSession = (agentId: string, title?: string): Promise<ChatSession> =>
    fetch(`${BASE}/sessions`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ agent_id: agentId, title: title || 'New session' }),
    }).then(r => r.json());

export const sendMessage = (sessionId: string, content: string) =>
    fetch(`${BASE}/chat`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ session_id: sessionId, content }),
    }).then(r => r.json());
