import { WorkflowSkill } from '../types';

interface Props {
    skill:    WorkflowSkill;
    index:    number;
    allSkills:WorkflowSkill[];
    onChange: (updated: WorkflowSkill) => void;
    onRemove: () => void;
}

export default function SkillCard({ skill, index, allSkills, onChange, onRemove }: Props) {
    const others = allSkills.filter((_, i) => i !== index);

    return (
        <div className='skill-card'>
            <div className='skill-top'>
                <span className='step-num'>{index + 1}</span>
                <span className='sk-name'>{skill.skill_display_name}</span>
                {skill.ds_name && (
                    <span className={`sk-ds ${skill.ds_name === 'factset' ? 'fs' : 'rag'}`}>
                        {skill.ds_name}
                    </span>
                )}
                <div className='en-toggle'>
                    <button className={`enb ${skill.enabled ? 'on' : ''}`}
                        onClick={() => onChange({ ...skill, enabled: true })}>On</button>
                    <button className={`enb ${!skill.enabled ? 'on' : ''}`}
                        onClick={() => onChange({ ...skill, enabled: false })}>Off</button>
                </div>
                <button className='xbtn' onClick={onRemove}>✕</button>
            </div>
            <div className='skill-fields'>
                <div className='sf'>
                    <label className='sf-lbl'>Entry point</label>
                    <div className='bool-toggle'>
                        <button className={`bopt ${skill.is_entry_point ? 'on' : ''}`}
                            onClick={() => onChange({ ...skill, is_entry_point: true })}>Yes</button>
                        <button className={`bopt ${!skill.is_entry_point ? 'on' : ''}`}
                            onClick={() => onChange({ ...skill, is_entry_point: false })}>No</button>
                    </div>
                </div>
                <div className='sf'>
                    <label className='sf-lbl'>Terminal</label>
                    <div className='bool-toggle'>
                        <button className={`bopt ${skill.is_terminal ? 'on' : ''}`}
                            onClick={() => onChange({ ...skill, is_terminal: true })}>Yes</button>
                        <button className={`bopt ${!skill.is_terminal ? 'on' : ''}`}
                            onClick={() => onChange({ ...skill, is_terminal: false })}>No</button>
                    </div>
                </div>
                <div className='sf'>
                    <label className='sf-lbl'>Next skill</label>
                    <select value={skill.next_skill_id || ''}
                        onChange={e => onChange({ ...skill, next_skill_id: e.target.value || null })}>
                        <option value=''>Default order</option>
                        {others.map(s => (
                            <option key={s.skill_id} value={s.skill_id}>{s.skill_display_name}</option>
                        ))}
                    </select>
                </div>
                <div className='sf'>
                    <label className='sf-lbl'>Condition</label>
                    <input type='text'
                        value={skill.condition || ''}
                        onChange={e => onChange({ ...skill, condition: e.target.value || null })}
                        placeholder='e.g. confirmed==false'
                    />
                </div>
            </div>
        </div>
    );
}
