import { ChatMessage } from '../types';

interface Props {
    message:     ChatMessage;
    letterDraft: string | null;
}

export default function MessageBubble({ message, letterDraft }: Props) {
    const isLetter = message.role === 'assistant' && letterDraft && message.content === letterDraft;

    const handleExport = () => {
        const blob = new Blob([message.content], { type: 'text/plain' });
        const url  = URL.createObjectURL(blob);
        const a    = document.createElement('a');
        a.href = url; a.download = 'activism-letter.md'; a.click();
        URL.revokeObjectURL(url);
    };

    const handleCopy = () => navigator.clipboard.writeText(message.content);

    return (
        <div className={`msg ${message.role}`}>
            {message.role === 'assistant' && (
                <div className='agent-tag'>Activism Agent</div>
            )}
            <div className={`bubble ${isLetter ? 'letter-bubble' : ''}`}>
                {message.content}
                {isLetter && (
                    <div className='letter-actions'>
                        <button className='la-btn primary' onClick={handleExport}>Export</button>
                        <button className='la-btn' onClick={handleCopy}>Copy</button>
                        <button className='la-btn'>New target</button>
                    </div>
                )}
            </div>
            <div className='msg-time'>
                {new Date(message.created_on).toLocaleTimeString('en-GB', {
                    hour: '2-digit', minute: '2-digit'
                })}
            </div>
        </div>
    );
}
