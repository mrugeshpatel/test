import { Agent, ChatSession } from '../types';

interface Props {
    agent:           Agent;
    sessions:        ChatSession[];
    activeSession:   ChatSession | null;
    onSelectSession: (s: ChatSession) => void;
    onNewSession:    () => void;
    onHome:          () => void;
}

export default function Sidebar({ agent, sessions, activeSession, onSelectSession, onNewSession, onHome }: Props) {
    return (
        <div className='sidebar'>
            <div className='sb-header'>
                <div className='sb-logo'>B</div>
                <div>
                    <div className='sb-brand'>Banker's One</div>
                    <div className='sb-sub'>Platform</div>
                </div>
            </div>
            <div className='sb-body'>
                <span className='nav-label'>Recent sessions</span>
                <button className='new-session-btn' onClick={onNewSession}>
                    + New session
                </button>
                {sessions.map(s => (
                    <div
                        key={s.id}
                        className={`session-item ${activeSession?.id === s.id ? 'active' : ''}`}
                        onClick={() => onSelectSession(s)}
                    >
                        <div className='si-title'>{s.title || 'Untitled session'}</div>
                        <div className='si-meta'>
                            {new Date(s.created_on).toLocaleDateString('en-GB')}
                        </div>
                    </div>
                ))}
                {sessions.length === 0 && (
                    <div className='hint' style={{ padding: '6px 8px' }}>
                        No sessions yet
                    </div>
                )}
            </div>
            <div className='sb-footer'>
                <button className='cfg-btn' onClick={onHome}>← Home</button>
            </div>
        </div>
    );
}
