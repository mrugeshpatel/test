import { useState } from 'react';
import { LogEntry } from '../hooks/useWebSocket';

interface Props {
    logs:      LogEntry[];
    connected: boolean;
}

export default function ExecutionLog({ logs, connected }: Props) {
    const [open, setOpen] = useState(false);

    return (
        <div className='collapse-card'>
            <div className='collapse-header' onClick={() => setOpen(o => !o)}>
                <span className='ch-title'>Execution log</span>
                <span className='ch-meta'>
                    {logs.length} steps · live only{connected ? ' · connected' : ''}
                </span>
                <span className={`chevron ${open ? 'open' : ''}`}>▼</span>
            </div>
            {open && (
                <div className='collapse-body open'>
                    <div className='exec-log'>
                        {logs.length === 0 && (
                            <div className='exec-empty'>No log entries yet · live via WebSocket · not stored in DB</div>
                        )}
                        {logs.map((log, i) => (
                            <div key={i} className='exec-row'>
                                <span className={`exec-ic ${log.status}`}>✓</span>
                                <span className='exec-label'>{log.message}</span>
                                <span className={`exec-status ${log.status}`}>{log.status}</span>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}
