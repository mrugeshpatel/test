import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { WorkflowSkill, AgentStatus } from '../types';

interface Props {
    skills:  WorkflowSkill[];
    status:  AgentStatus | null;
    agentId?: string;
}

export default function WorkflowPanel({ skills, status, agentId }: Props) {
    const [open, setOpen] = useState(false);
    const navigate        = useNavigate();

    const activeCount = skills.filter(s => s.enabled).length;

    return (
        <div className='collapse-card'>
            <div className='collapse-header' onClick={() => setOpen(o => !o)}>
                <span className='ch-title'>Workflow steps</span>
                <span className='ch-meta'>
                    {activeCount} of {skills.length} steps active
                </span>
                <span className={`chevron ${open ? 'open' : ''}`}>▼</span>
            </div>
            {open && (
                <div className='collapse-body open'>
                    <div className='wf-steps'>
                        {skills.length === 0 && (
                            <div className='exec-empty'>
                                No workflow steps configured · click Edit agent to add skills
                            </div>
                        )}
                        {skills.map((s, i) => {
                            const skillStatus = status?.skills.find(ss => ss.skill_name === s.skill_name);
                            const available   = skillStatus?.ds_enabled !== false;
                            return (
                                <div key={s.id}
                                    className={`step-row ${!s.enabled ? 'step-row-disabled' : ''}`}>
                                    <span className='step-num'
                                        style={!s.enabled ? { background: '#CBD5E1' } : {}}>
                                        {i + 1}
                                    </span>
                                    <span className='step-name'
                                        style={!s.enabled ? { color: '#9CA3AF' } : {}}>
                                        {s.skill_display_name}
                                    </span>
                                    {s.ds_name && (
                                        <span className={`ds-badge ${s.ds_name} ${!available ? 'unavailable' : ''}`}>
                                            {s.ds_name}{!available ? ' ⚠' : ''}
                                        </span>
                                    )}
                                    {!s.enabled && (
                                        <span className='status-badge pending'>Off</span>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                    {agentId && (
                        <div style={{ padding: '6px 14px 8px', borderTop: '0.5px solid #E2E8F0' }}>
                            <button
                                className='btn-accent'
                                onClick={() => navigate(`/agent/${agentId}`)}
                                style={{ fontSize: 11, padding: '4px 10px' }}>
                                Edit agent to add · remove · reorder steps
                            </button>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}
