import { useEffect, useRef } from 'react';
import { ChatMessage } from '../types';
import MessageBubble from './MessageBubble';

interface Props {
    messages:    ChatMessage[];
    letterDraft: string | null;
}

export default function ChatWindow({ messages, letterDraft }: Props) {
    const bottomRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    return (
        <div className='chat-window'>
            {messages.length === 0 && (
                <div className='exec-empty'>Start a conversation with the agent</div>
            )}
            {messages.map(msg => (
                <MessageBubble
                    key={msg.id}
                    message={msg}
                    letterDraft={letterDraft}
                />
            ))}
            <div ref={bottomRef} />
        </div>
    );
}
