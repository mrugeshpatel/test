import { useRef, useState } from 'react';

interface Props {
    onDrop:   (files: File[]) => void;
    accept?:  string;
    loading?: boolean;
}

export default function DropZone({ onDrop, accept, loading }: Props) {
    const [dragging, setDragging] = useState(false);
    const inputRef = useRef<HTMLInputElement>(null);

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        setDragging(false);
        const files = Array.from(e.dataTransfer.files);
        if (files.length) onDrop(files);
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = Array.from(e.target.files || []);
        if (files.length) onDrop(files);
        e.target.value = '';
    };

    return (
        <div
            className={`drop-zone ${dragging ? 'dragging' : ''} ${loading ? 'loading' : ''}`}
            onClick={() => inputRef.current?.click()}
            onDragOver={e => { e.preventDefault(); setDragging(true); }}
            onDragLeave={() => setDragging(false)}
            onDrop={handleDrop}
        >
            <input ref={inputRef} type='file' multiple
                accept={accept} onChange={handleChange}
                style={{ display: 'none' }} />
            <div className='drop-icon'>↑</div>
            <div>
                <div className='drop-title'>
                    {loading ? 'Uploading...' : 'Drag and drop activism letters · or click to select'}
                </div>
                <div className='drop-sub'>
                    Agent auto-detects activist · verify in dropdown · then Embed
                </div>
                <div className='drop-formats'>
                    {['PDF', 'DOCX', 'TXT'].map(f => (
                        <span key={f} className='fmt'>{f}</span>
                    ))}
                </div>
            </div>
        </div>
    );
}
