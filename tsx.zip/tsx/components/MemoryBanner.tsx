interface Props {
    memory:   Record<string, unknown>;
    onClear?: () => void;
}

export default function MemoryBanner({ memory, onClear }: Props) {
    const lastCompany = memory?.last_company as string | undefined;
    const lastStyle   = memory?.last_style   as string | undefined;
    if (!lastCompany && !lastStyle) return null;
    return (
        <div className='memory-banner'>
            <span className='mem-text'>
                Last session:
                {lastCompany && ` ${lastCompany}`}
                {lastStyle   && ` — ${lastStyle}`}
            </span>
            {onClear && (
                <button className='mem-clear' onClick={onClear}>Clear</button>
            )}
        </div>
    );
}
