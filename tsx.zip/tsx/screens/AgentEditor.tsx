import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { WorkflowSkill } from '../types';
import { fetchAgent, createAgent, updateAgent } from '../api/agents';
import { fetchSkills } from '../api/skills';
import SkillCard from '../components/SkillCard';

export default function AgentEditor() {
    const { agentId } = useParams<{ agentId: string }>();
    const navigate    = useNavigate();
    const isEdit      = Boolean(agentId);

    const [name,            setName]            = useState('');
    const [displayName,     setDisplayName]     = useState('');
    const [description,     setDescription]     = useState('');
    const [systemPrompt,    setSystemPrompt]    = useState('');
    const [guardrails,      setGuardrails]      = useState('');
    const [interruptBefore, setInterruptBefore] = useState<string[]>([]);
    const [skills,          setSkills]          = useState<WorkflowSkill[]>([]);
    const [allSkills,       setAllSkills]       = useState<any[]>([]);
    const [formOpen,        setFormOpen]        = useState(true);
    const [testStarted,     setTestStarted]     = useState(false);
    const [testMessages,    setTestMessages]    = useState<any[]>([]);
    const [testInput,       setTestInput]       = useState('');
    const [saving,          setSaving]          = useState(false);

    useEffect(() => {
        fetchSkills().then(setAllSkills).catch(console.error);
    }, []);

    useEffect(() => {
        if (!agentId) return;
        fetchAgent(agentId).then(agent => {
            setName(agent.name);
            setDisplayName(agent.display_name);
            setDescription(agent.description || '');
            setSystemPrompt(agent.system_prompt);
            setGuardrails(agent.guardrails || '');
            setInterruptBefore(agent.interrupt_before || []);
            setSkills((agent as any).workflow_skills || []);
        }).catch(console.error);
    }, [agentId]);

    const handleSave = async () => {
        setSaving(true);
        try {
            const body = {
                name,
                display_name:     displayName,
                description,
                system_prompt:    systemPrompt,
                guardrails,
                interrupt_before: interruptBefore,
            };
            if (isEdit && agentId) {
                await updateAgent(agentId, body);
            } else {
                await createAgent(body);
            }
            navigate('/');
        } catch (e) {
            console.error(e);
        } finally {
            setSaving(false);
        }
    };

    const toggleInterrupt = (skillName: string) => {
        setInterruptBefore(prev =>
            prev.includes(skillName)
                ? prev.filter(s => s !== skillName)
                : [...prev, skillName]
        );
    };

    return (
        <div className='agent-page'>
            <div className='topbar'>
                <div className='tb-left'>
                    <button className='back-btn' onClick={() => navigate('/')}>← Back</button>
                    <span className='page-title'>
                        {isEdit ? 'Edit agent' : 'Create agent'}
                    </span>
                </div>
                <div className='tb-right'>
                    <button className='btn' onClick={() => navigate('/')}>Cancel</button>
                    <button className='btn-accent' onClick={() => setTestStarted(true)}>
                        Run and test
                    </button>
                    <button className='btn-primary' onClick={handleSave} disabled={saving}>
                        {saving ? 'Saving...' : 'Save'}
                    </button>
                </div>
            </div>

            {/* Config form */}
            <div className='form-panel'>
                <div className='form-header' onClick={() => setFormOpen(o => !o)}>
                    <span>Configuration</span>
                    <span>{formOpen ? '▲' : '▼'}</span>
                </div>
                {formOpen && (
                    <div className='form-body'>
                        <div className='form-section'>
                            <h3>Basics</h3>
                            <div className='field-row'>
                                <div className='field'>
                                    <label className='lbl'>Agent name</label>
                                    <input type='text' value={name}
                                        onChange={e => setName(e.target.value)}
                                        disabled={isEdit}
                                        className={isEdit ? 'locked' : ''}
                                        placeholder='e.g. activism-agent-value' />
                                    {isEdit && (
                                        <span className='hint'>Locked — used as LangGraph node ID</span>
                                    )}
                                </div>
                                <div className='field'>
                                    <label className='lbl'>Display name</label>
                                    <input type='text' value={displayName}
                                        onChange={e => setDisplayName(e.target.value)}
                                        placeholder='e.g. Activism Agent' />
                                </div>
                            </div>
                            <div className='field'>
                                <label className='lbl'>System prompt</label>
                                <textarea rows={3} value={systemPrompt}
                                    onChange={e => setSystemPrompt(e.target.value)}
                                    placeholder='You are an expert IBD activism analyst...' />
                            </div>
                            <div className='field'>
                                <label className='lbl'>Guardrails
                                    <span className='opt-tag'>optional</span>
                                </label>
                                <textarea rows={2} value={guardrails}
                                    onChange={e => setGuardrails(e.target.value)}
                                    placeholder='Do not discuss confidential matters...' />
                            </div>
                            <div className='field'>
                                <label className='lbl'>
                                    Pause at steps
                                    <span className='opt-tag'>empty = fully autonomous</span>
                                </label>
                                <div className='interrupt-list'>
                                    {skills.map(s => (
                                        <label key={s.skill_name}
                                            className={`int-chip ${interruptBefore.includes(s.skill_name) ? 'checked' : ''}`}>
                                            <input type='checkbox'
                                                checked={interruptBefore.includes(s.skill_name)}
                                                onChange={() => toggleInterrupt(s.skill_name)} />
                                            {s.skill_name}
                                        </label>
                                    ))}
                                    {skills.length === 0 && (
                                        <span className='hint'>Add skills below to configure pause points</span>
                                    )}
                                </div>
                            </div>
                        </div>

                        <div className='form-section'>
                            <h3>
                                Workflow
                                <span className='section-meta'>
                                    skills = LangGraph nodes · order = edges
                                </span>
                            </h3>
                            <div className='skills-list'>
                                {skills.map((s, i) => (
                                    <SkillCard
                                        key={s.id || i}
                                        skill={s}
                                        index={i}
                                        allSkills={skills}
                                        onChange={updated => setSkills(prev =>
                                            prev.map((sk, idx) => idx === i ? updated : sk))}
                                        onRemove={() => setSkills(prev =>
                                            prev.filter((_, idx) => idx !== i))}
                                    />
                                ))}
                                {skills.length === 0 && (
                                    <div className='empty-state'>
                                        No skills added yet — select from the dropdown below
                                    </div>
                                )}
                            </div>
                            <div className='add-row'>
                                <select onChange={e => {
                                    const sk = allSkills.find(s => s.id === e.target.value);
                                    if (sk) setSkills(prev => [...prev, {
                                        id:                 sk.id,
                                        skill_id:           sk.id,
                                        skill_name:         sk.name,
                                        skill_display_name: sk.display_name,
                                        step_order:         prev.length + 1,
                                        next_skill_id:      null,
                                        condition:          null,
                                        is_entry_point:     prev.length === 0,
                                        is_terminal:        false,
                                        enabled:            true,
                                        ds_name:            sk.ds_name,
                                    }]);
                                    e.target.value = '';
                                }}>
                                    <option value=''>Select a skill to add...</option>
                                    {allSkills.map(s => (
                                        <option key={s.id} value={s.id}>
                                            {s.display_name} — {s.ds_name || 'none'}
                                        </option>
                                    ))}
                                </select>
                                <button className='btn-accent'
                                    onClick={() => navigate('/skills')}>
                                    Skill library
                                </button>
                            </div>
                            <div className='lg-note'>
                                Skills become LangGraph nodes · edges built from order ·
                                graph_config saved automatically on Save
                            </div>
                        </div>
                    </div>
                )}
            </div>

            {/* Test panel */}
            <div className='test-panel'>
                <div className='test-header'>
                    <span>Test</span>
                    <span className='test-note-label'>
                        Not saved · config in memory only · zero DB writes
                    </span>
                </div>
                {!testStarted ? (
                    <div className='test-empty'>
                        <p>Test your agent before saving</p>
                        <button className='btn-accent' onClick={() => setTestStarted(true)}>
                            Run and test
                        </button>
                    </div>
                ) : (
                    <div className='test-chat'>
                        <div className='test-messages'>
                            <div className='test-msg assistant'>
                                Agent loaded with current config. Which company are you targeting?
                            </div>
                            {testMessages.map((m, i) => (
                                <div key={i} className={`test-msg ${m.role}`}>{m.content}</div>
                            ))}
                        </div>
                        <div className='test-input'>
                            <div className='chat-input-wrap'>
                                <input
                                    value={testInput}
                                    onChange={e => setTestInput(e.target.value)}
                                    onKeyDown={e => {
                                        if (e.key === 'Enter' && testInput.trim()) {
                                            setTestMessages(prev => [
                                                ...prev,
                                                { role: 'user',      content: testInput },
                                                { role: 'assistant', content: 'Test response — backend not connected in test mode' },
                                            ]);
                                            setTestInput('');
                                        }
                                    }}
                                    placeholder='Type to test...'
                                />
                                <button className='send-btn' onClick={() => {
                                    if (!testInput.trim()) return;
                                    setTestMessages(prev => [
                                        ...prev,
                                        { role: 'user',      content: testInput },
                                        { role: 'assistant', content: 'Test response — backend not connected in test mode' },
                                    ]);
                                    setTestInput('');
                                }}>→</button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
