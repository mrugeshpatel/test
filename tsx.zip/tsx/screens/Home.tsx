import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Agent } from '../types';
import { fetchAgents } from '../api/agents';

export default function Home() {
    const [agents,  setAgents]  = useState<Agent[]>([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        fetchAgents().then(setAgents).catch(console.error).finally(() => setLoading(false));
    }, []);

    if (loading) return <div className='loading'>Loading...</div>;

    return (
        <div className='home'>
            <div className='home-header'>
                <div className='home-logo'><span>B</span></div>
                <h1>Banker's One Platform</h1>
            </div>

            <div className='home-body'>
                <span className='section-label'>Agents</span>
                <div className='agents-grid'>
                    {agents.map(agent => (
                        <div key={agent.id} className='agent-card'
                            onClick={() => navigate(`/workspace/${agent.id}`)}>
                            <div className='ac-stripe' />
                            <div className='ac-body'>
                                <div className='ac-top'>
                                    <div className='ac-icon'>A</div>
                                    <button className='edit-btn'
                                        onClick={e => { e.stopPropagation(); navigate(`/agent/${agent.id}`); }}>
                                        ✎
                                    </button>
                                </div>
                                <div className='ac-name'>{agent.display_name}</div>
                                <div className='ac-footer'>
                                    <span className='ac-meta'>
                                        {new Date(agent.updated_on).toLocaleDateString('en-GB', {
                                            day: 'numeric', month: 'short', year: 'numeric'
                                        })}
                                    </span>
                                    <button className='open-btn'
                                        onClick={e => { e.stopPropagation(); navigate(`/workspace/${agent.id}`); }}>
                                        Open →
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                    {agents.length === 0 && (
                        <div className='empty-state'>No agents yet — create one below</div>
                    )}
                </div>

                <hr className='section-divider' />

                <span className='section-label'>Configuration</span>
                <div className='config-grid'>
                    <div className='config-card' onClick={() => navigate('/agent/new')}>
                        <div className='cc-icon'>+</div>
                        <div>
                            <div className='cc-name'>Create agent</div>
                            <div className='cc-desc'>Build a new agent</div>
                        </div>
                    </div>
                    <div className='config-card' onClick={() => navigate('/skills')}>
                        <div className='cc-icon'>S</div>
                        <div>
                            <div className='cc-name'>Skill library</div>
                            <div className='cc-desc'>Add and manage skills</div>
                        </div>
                    </div>
                    <div className='config-card' onClick={() => navigate('/upload')}>
                        <div className='cc-icon'>U</div>
                        <div>
                            <div className='cc-name'>Upload letters</div>
                            <div className='cc-desc'>Style training corpus</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
