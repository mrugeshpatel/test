import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ActivismLetter, StyleVector } from '../types';
import {
    fetchLetters, fetchVectors, uploadLetters,
    updateActivist, embedLetter, deleteLetter, deleteVector
} from '../api/letters';
import DropZone from '../components/DropZone';

const KNOWN_ACTIVISTS = ['Elliott', 'Starboard', 'Third Point', 'ValueAct', 'Pershing Square'];

export default function UploadLetters() {
    const navigate = useNavigate();
    const [letters,   setLetters]   = useState<ActivismLetter[]>([]);
    const [vectors,   setVectors]   = useState<StyleVector[]>([]);
    const [uploading, setUploading] = useState(false);
    const [loading,   setLoading]   = useState(true);

    useEffect(() => {
        Promise.all([fetchLetters(), fetchVectors()])
            .then(([l, v]) => { setLetters(l); setVectors(v); })
            .catch(console.error)
            .finally(() => setLoading(false));
    }, []);

    const handleDrop = async (files: File[]) => {
        setUploading(true);
        try {
            const created = await uploadLetters(files);
            setLetters(prev => [...created, ...prev]);
        } catch (e) {
            console.error(e);
        } finally {
            setUploading(false);
        }
    };

    const handleActivistChange = async (letter: ActivismLetter, activist: string) => {
        const updated = await updateActivist(letter.id, activist);
        setLetters(prev => prev.map(l => l.id === updated.id ? updated : l));
    };

    const handleEmbed = async (letter: ActivismLetter) => {
        await embedLetter(letter.id);
        const [l, v] = await Promise.all([fetchLetters(), fetchVectors()]);
        setLetters(l); setVectors(v);
    };

    const handleDeleteLetter = async (id: string) => {
        await deleteLetter(id);
        setLetters(prev => prev.filter(l => l.id !== id));
    };

    const handleDeleteVector = async (activist: string) => {
        await deleteVector(activist);
        setVectors(prev => prev.filter(v => v.activist !== activist));
    };

    if (loading) return <div className='loading'>Loading...</div>;

    return (
        <div className='upload-page'>
            <div className='topbar'>
                <div className='tb-left'>
                    <button className='back-btn' onClick={() => navigate('/')}>← Home</button>
                    <span className='page-title'>Upload Letters</span>
                </div>
            </div>

            <div className='upload-body'>
                <DropZone onDrop={handleDrop} accept='.pdf,.docx,.txt' loading={uploading} />

                {/* Letters table */}
                <div>
                    <div className='section-header'>
                        <span className='sec-lbl'>
                            Uploaded letters
                            <span className='count-badge'>{letters.length}</span>
                        </span>
                        <span className='section-meta'>sorted newest first · activism_letters table</span>
                    </div>
                    <div className='letters-wrap'>
                        <table className='letters-table'>
                            <thead>
                                <tr>
                                    <th>Document</th>
                                    <th>Detected activist</th>
                                    <th>Status</th>
                                    <th>Uploaded</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {letters.map(letter => (
                                    <tr key={letter.id}>
                                        <td><div className='filename'>{letter.filename}</div></td>
                                        <td>
                                            <div className='activist-sel'>
                                                <select
                                                    value={letter.activist || ''}
                                                    onChange={e => handleActivistChange(letter, e.target.value)}>
                                                    <option value=''>Select activist...</option>
                                                    {KNOWN_ACTIVISTS.map(a => (
                                                        <option key={a} value={a}>{a}</option>
                                                    ))}
                                                </select>
                                                {letter.activist && (
                                                    <span className='auto-badge'>auto</span>
                                                )}
                                            </div>
                                        </td>
                                        <td>
                                            <span className={`status-badge ${letter.processed ? 'done' : 'pending'}`}>
                                                {letter.processed ? 'Done' : 'Pending'}
                                            </span>
                                        </td>
                                        <td>{new Date(letter.uploaded_on).toLocaleDateString('en-GB')}</td>
                                        <td>
                                            <div className='row-btns'>
                                                <button className='rbtn embed'
                                                    onClick={() => handleEmbed(letter)}
                                                    disabled={!letter.activist}
                                                    title={!letter.activist ? 'Select activist first' : 'Embed'}>
                                                    Embed
                                                </button>
                                                <button className='rbtn del'
                                                    onClick={() => handleDeleteLetter(letter.id)}>
                                                    Delete
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                                {letters.length === 0 && (
                                    <tr><td colSpan={5} style={{ textAlign: 'center', color: '#6B7280', padding: 16 }}>
                                        No letters uploaded yet
                                    </td></tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* Vectors table */}
                <div>
                    <div className='section-header'>
                        <span className='sec-lbl'>
                            Activist style vectors
                            <span className='count-badge'>{vectors.length}</span>
                        </span>
                        <span className='section-meta'>activism_style_vectors · Titan v2 · 1024 dims · HNSW</span>
                    </div>
                    <div className='tbl-wrap'>
                        <table className='vectors-table'>
                            <thead>
                                <tr>
                                    <th>Activist</th>
                                    <th>Letters</th>
                                    <th>Sample text</th>
                                    <th>Updated</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                {vectors.map(v => (
                                    <tr key={v.id}>
                                        <td className='vname'>{v.activist}</td>
                                        <td><span className='lc-badge'>{v.letter_count}</span></td>
                                        <td className='vsample'>{v.sample_text}</td>
                                        <td>{new Date(v.updated_on).toLocaleDateString('en-GB')}</td>
                                        <td>
                                            <button className='rbtn del'
                                                onClick={() => handleDeleteVector(v.activist)}>
                                                Delete
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                                {vectors.length === 0 && (
                                    <tr><td colSpan={5} style={{ textAlign: 'center', color: '#6B7280', padding: 16 }}>
                                        No vectors yet — upload and embed letters above
                                    </td></tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}
