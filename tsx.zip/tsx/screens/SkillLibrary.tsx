import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Skill } from '../types';
import { fetchSkills, createSkill, updateSkill, deleteSkill } from '../api/skills';

const EMPTY_FORM = { name: '', display_name: '', description: '', content: '', data_source_id: '' };

export default function SkillLibrary() {
    const navigate = useNavigate();
    const [skills,  setSkills]  = useState<Skill[]>([]);
    const [editing, setEditing] = useState<Skill | null>(null);
    const [isNew,   setIsNew]   = useState(false);
    const [form,    setForm]    = useState(EMPTY_FORM);
    const [saving,  setSaving]  = useState(false);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchSkills().then(setSkills).catch(console.error).finally(() => setLoading(false));
    }, []);

    const openNew = () => {
        setForm(EMPTY_FORM);
        setEditing(null);
        setIsNew(true);
    };

    const editSkill = (skill: Skill) => {
        setForm({
            name:           skill.name,
            display_name:   skill.display_name,
            description:    skill.description || '',
            content:        skill.content,
            data_source_id: skill.data_source_id || '',
        });
        setEditing(skill);
        setIsNew(false);
    };

    const handleCancel = () => { setEditing(null); setIsNew(false); };

    const handleSave = async () => {
        setSaving(true);
        try {
            if (isNew) {
                const created = await createSkill(form);
                setSkills(prev => [...prev, created]);
            } else if (editing) {
                const updated = await updateSkill(editing.id, {
                    display_name:   form.display_name,
                    description:    form.description,
                    content:        form.content,
                    data_source_id: form.data_source_id || undefined,
                });
                setSkills(prev => prev.map(s => s.id === updated.id ? updated : s));
            }
            handleCancel();
        } catch (e) {
            console.error(e);
        } finally {
            setSaving(false);
        }
    };

    const handleDelete = async (skill: Skill) => {
        if (skill.linked_agents?.length > 0) return;
        if (!confirm(`Delete skill "${skill.display_name}"?`)) return;
        await deleteSkill(skill.id);
        setSkills(prev => prev.filter(s => s.id !== skill.id));
    };

    const showEditor = editing !== null || isNew;

    if (loading) return <div className='loading'>Loading...</div>;

    return (
        <div className='skill-page'>
            <div className='topbar'>
                <div className='tb-left'>
                    {showEditor && (
                        <button className='back-btn' onClick={handleCancel}>← Back</button>
                    )}
                    {!showEditor && (
                        <button className='back-btn' onClick={() => navigate('/')}>← Home</button>
                    )}
                    <span className='page-title'>
                        {showEditor ? (isNew ? 'New Skill' : 'Edit Skill') : 'Skill Library'}
                    </span>
                </div>
                <div className='tb-right'>
                    {!showEditor && (
                        <button className='btn-primary' onClick={openNew}>+ New Skill</button>
                    )}
                    {showEditor && (
                        <>
                            <button onClick={handleCancel}>Cancel</button>
                            <button className='btn-primary' onClick={handleSave} disabled={saving}>
                                {saving ? 'Saving...' : 'Save'}
                            </button>
                        </>
                    )}
                </div>
            </div>

            {!showEditor ? (
                <div className='skill-body'>
                    <div className='list-header'>
                        <span className='list-count'>{skills.length} skills</span>
                    </div>
                    <div className='tbl-wrap'>
                        <table className='skills-table'>
                            <thead>
                                <tr>
                                    <th>Skill</th>
                                    <th>Data source</th>
                                    <th>Status</th>
                                    <th>Linked to</th>
                                    <th>Description</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {skills.map(skill => (
                                    <tr key={skill.id}>
                                        <td className='skill-name'>{skill.display_name}</td>
                                        <td>
                                            {skill.ds_name && (
                                                <span className={`ds-badge ${skill.ds_name}`}>
                                                    {skill.ds_name}
                                                </span>
                                            )}
                                        </td>
                                        <td>
                                            <span className={`status-badge ${skill.enabled ? 'done' : 'pending'}`}>
                                                {skill.enabled ? 'On' : 'Off'}
                                            </span>
                                        </td>
                                        <td>
                                            {skill.linked_agents?.length > 0
                                                ? skill.linked_agents.map(a => (
                                                    <span key={a} className='agent-chip'>{a}</span>
                                                ))
                                                : <span className='no-link'>—</span>
                                            }
                                        </td>
                                        <td className='skill-desc'>{skill.description}</td>
                                        <td>
                                            <div className='act-btns'>
                                                <button className='act-btn' onClick={() => editSkill(skill)}>
                                                    Edit
                                                </button>
                                                <button className='act-btn del'
                                                    onClick={() => handleDelete(skill)}
                                                    disabled={skill.linked_agents?.length > 0}
                                                    title={skill.linked_agents?.length > 0 ? 'Remove from agents first' : ''}>
                                                    Delete
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            ) : (
                <div className='skill-body'>
                    <div className='skill-editor'>
                        {editing && editing.linked_agents?.length > 0 && (
                            <div className='linked-warn'>
                                ⚠ Linked to: {editing.linked_agents.join(', ')} — changes apply immediately on save
                            </div>
                        )}
                        <div className='field-row-3'>
                            <div className='field'>
                                <label className='lbl'>Skill name</label>
                                <input type='text' value={form.name}
                                    onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                                    readOnly={!isNew}
                                    className={!isNew ? 'locked' : ''}
                                    placeholder='e.g. find-company' />
                                {!isNew && <span className='hint'>Name locked after creation</span>}
                            </div>
                            <div className='field'>
                                <label className='lbl'>Display name</label>
                                <input type='text' value={form.display_name}
                                    onChange={e => setForm(f => ({ ...f, display_name: e.target.value }))}
                                    placeholder='e.g. Find Company' />
                            </div>
                            <div className='field'>
                                <label className='lbl'>Data source</label>
                                <select value={form.data_source_id}
                                    onChange={e => setForm(f => ({ ...f, data_source_id: e.target.value }))}>
                                    <option value=''>None</option>
                                    <option value='factset'>factset</option>
                                    <option value='rag-activism'>rag-activism</option>
                                    <option value='web'>web</option>
                                </select>
                            </div>
                        </div>
                        <div className='field'>
                            <label className='lbl'>Description</label>
                            <input type='text' value={form.description}
                                onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                                placeholder='Short description' />
                        </div>
                        <div className='field'>
                            <label className='lbl'>
                                Content — WHAT the agent does in this step
                            </label>
                            <textarea rows={12} value={form.content}
                                onChange={e => setForm(f => ({ ...f, content: e.target.value }))}
                                placeholder='Write skill instructions...'
                                style={{ fontFamily: 'monospace', fontSize: 12 }} />
                            <span className='hint'>Injected into system prompt at runtime · no cache</span>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
